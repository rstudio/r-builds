from __future__ import annotations

import itertools
import logging
import os
import platform
import shutil
import stat
from os.path import abspath, basename, dirname, exists, isabs
from os.path import join as pjoin
from pathlib import Path
from subprocess import check_call
from typing import Iterable

from auditwheel.patcher import ElfPatcher

from auditwheel.elfutils import elf_read_dt_needed, elf_read_rpaths
from auditwheel.hashfile import hashfile
from auditwheel.tools import is_subdir

from .r_abi import WheelAbIInfo
from .genericpkgctx import InGenericPkgCtx
from .rtools import add_platform

logger = logging.getLogger(__name__)


def repair_r(
    wheel_abi: WheelAbIInfo,
    package_path: str,
    abis: list[str],
    lib_sdir: str,
    out_dir: str,
    update_tags: bool,
    patcher: ElfPatcher,
    exclude: frozenset[str],
    strip: bool = False,
) -> str | None:
    external_refs_by_fn = wheel_abi.full_external_refs

    # Do not repair a pure R package, i.e. has no external refs
    if not external_refs_by_fn:
        return None

    soname_map: dict[str, tuple[str, Path]] = {}
    if not isabs(out_dir):
        out_dir = abspath(out_dir)

    package_fname = basename(package_path)

    with InGenericPkgCtx(package_path) as ctx:
        ctx.out_path = pjoin(out_dir, package_fname)

        dest_dir = pjoin(ctx.package_libs_path, lib_sdir)

        logger.debug(f"repairing package '{ctx.package_name}' at '{package_path}'. "
                     f"Copied libraries will be written to '{dest_dir}'. "
                     f"Package will be written to '{ctx.out_path}'.")

        # here, fn is a path to an ELF file (lib or executable) in
        # the package, and v['libs'] contains its required libs
        for fn, v in external_refs_by_fn.items():
            ext_libs = v[abis[0]].libs
            replacements: list[tuple[str, str]] = []
            logger.debug("repairing %s with ext_libs: %s", fn, ext_libs)
            for soname, src_path in ext_libs.items():
                assert soname not in exclude

                if src_path is None:
                    # If packages link against R's shared BLAS/LAPACK libraries and they can't be found,
                    # the repaired binary will not be portable across R installations.
                    if soname in ['libRblas.so', 'libRlapack.so']:
                        raise ValueError(f"Cannot repair package, because required library '{soname}' could not be located. "
                                         f"If R was built with the shared BLAS/LAPACK libraries, you must either add "
                                         f"R_HOME/lib to LD_LIBRARY_PATH when repairing, or build R with external "
                                         f"BLAS/LAPACK, or modify the R installation so that packages link against "
                                         f"external BLAS/LAPACK libraries.")

                    # In rare cases, R packages build libraries that assume other libraries have already been loaded.
                    # For example, RcppParallel includes libtbbmalloc_proxy.so that depends on libtbbmalloc.so, but
                    # does not include an rpath to find it. This is intentional, as the package knows to load
                    # libtbbmalloc before libtbbmalloc_proxy from R. We can't fix this, so we exclude these
                    # libraries from repair and assume that they are intentional.
                    if is_subdir(fn, ctx.package_path):
                        logger.warning(f"Required library {soname} could not be located for library '{fn}'. "
                                       f"Skipping rpath replacement because library '{fn}' is internal to the package.")
                        continue

                    raise ValueError(
                        (
                            "Cannot repair package, because required "
                            'library "%s" could not be located'
                        )
                        % soname
                    )

                if not exists(dest_dir):
                    os.makedirs(dest_dir)
                new_soname, new_path = copylib(src_path, dest_dir, patcher)
                soname_map[soname] = (new_soname, new_path)
                replacements.append((soname, new_soname))
            if replacements:
                patcher.replace_needed(fn, *replacements)

            if len(ext_libs) > 0:
                new_rpath = os.path.relpath(dest_dir, os.path.dirname(fn))
                new_rpath = os.path.join("$ORIGIN", new_rpath)
                logger.debug(f"appending new rpath '{new_rpath}' within lib '{fn}'")
                append_rpath_within_package(fn, new_rpath, ctx.package_path, patcher)

        # we grafted in a bunch of libraries and modified their sonames, but
        # they may have internal dependencies (DT_NEEDED) on one another, so
        # we need to update those records so each now knows about the new
        # name of the other.
        for old_soname, (new_soname, path) in soname_map.items():
            needed = elf_read_dt_needed(path)
            replacements = []
            for n in needed:
                if n in soname_map:
                    replacements.append((n, soname_map[n][0]))
            if replacements:
                patcher.replace_needed(path, *replacements)

        if update_tags:
            ctx.out_path = add_platform(ctx, abis[0])

        if strip:
            libs_to_strip = [path for (_, path) in soname_map.values()]
            extensions = external_refs_by_fn.keys()
            # Bundled shared libs
            logger.debug("Stripping libs: %s", libs_to_strip)
            # Extensions include the package shared lib and potentially other binaries/libs
            logger.debug("Stripping extensions: %s", extensions)
            strip_symbols(itertools.chain(libs_to_strip, extensions))

    return ctx.out_path


def strip_symbols(libraries: Iterable[str]) -> None:
    for lib in libraries:
        logger.info("Stripping symbols from %s", lib)
        # Match R's default strip command with --strip-unneeded instead of -s/--strip-all
        check_call(["strip", "--strip-unneeded", lib])


def copylib(src_path: str, dest_dir: str, patcher: ElfPatcher) -> tuple[str, str]:
    """Graft a shared library from the system into the package and update the
    relevant links.

    1) Copy the file from src_path to dest_dir/
    2) Rename the shared object from soname to soname.<unique>
    3) If the library has a RUNPATH/RPATH, clear it and set RPATH to point to
    its new location.
    """
    # Copy the shared library from the system (src_path) into the package
    # if the library has a RUNPATH/RPATH we clear it and set RPATH to point to
    # its new location.

    with open(src_path, "rb") as f:
        shorthash = hashfile(f)[:8]

    src_name = os.path.basename(src_path)
    base, ext = src_name.split(".", 1)
    if not base.endswith("-%s" % shorthash):
        new_soname = f"{base}-{shorthash}.{ext}"
    else:
        new_soname = src_name

    dest_path = os.path.join(dest_dir, new_soname)
    if os.path.exists(dest_path):
        return new_soname, dest_path

    logger.debug("Grafting: %s -> %s", src_path, dest_path)
    rpaths = elf_read_rpaths(src_path)
    shutil.copy2(src_path, dest_path)
    statinfo = os.stat(dest_path)
    if not statinfo.st_mode & stat.S_IWRITE:
        os.chmod(dest_path, statinfo.st_mode | stat.S_IWRITE)

    patcher.set_soname(dest_path, new_soname)

    if any(itertools.chain(rpaths["rpaths"], rpaths["runpaths"])):
        patcher.set_rpath(dest_path, "$ORIGIN")

    return new_soname, dest_path


def append_rpath_within_package(
    lib_name: str, rpath: str, package_base_dir: str, patcher: ElfPatcher
) -> None:
    """Add a new rpath entry to a file while preserving as many existing
    rpath entries as possible.

    In order to preserve an rpath entry it must:

    1) Point to a location within package_base_dir.
    2) Not be a duplicate of an already-existing rpath entry.
    """
    if not isabs(lib_name):
        lib_name = abspath(lib_name)
    lib_dir = dirname(lib_name)
    if not isabs(package_base_dir):
        package_base_dir = abspath(package_base_dir)

    def is_valid_rpath(rpath: str) -> bool:
        return _is_valid_rpath(rpath, lib_dir, package_base_dir)

    old_rpaths = patcher.get_rpath(lib_name)
    rpaths = filter(is_valid_rpath, old_rpaths.split(":"))
    # Remove duplicates while preserving ordering
    # Fake an OrderedSet using a dict (ordered in python 3.7+)
    rpath_set = {old_rpath: "" for old_rpath in rpaths}
    rpath_set[rpath] = ""

    patcher.set_rpath(lib_name, ":".join(rpath_set))


def _is_valid_rpath(rpath: str, lib_dir: str, package_base_dir: str) -> bool:
    full_rpath_entry = _resolve_rpath_tokens(rpath, lib_dir)
    if not isabs(full_rpath_entry):
        logger.debug(
            f"rpath entry {rpath} could not be resolved to an "
            "absolute path -- discarding it."
        )
        return False

    # Preserve relative $ORIGIN rpath entries that point within the package
    if is_subdir(full_rpath_entry, package_base_dir) or full_rpath_entry == package_base_dir:
        logger.debug(f"Preserved rpath entry {rpath}")
        return True

    logger.debug(
        f"rpath entry {rpath} ({full_rpath_entry}) points outside the package ({package_base_dir}, {lib_dir}) -- " "discarding it."
    )
    return False


def _resolve_rpath_tokens(rpath: str, lib_base_dir: str) -> str:
    # See https://www.man7.org/linux/man-pages/man8/ld.so.8.html#DESCRIPTION
    if platform.architecture()[0] == "64bit":
        system_lib_dir = "lib64"
    else:
        system_lib_dir = "lib"
    system_processor_type = platform.machine()
    token_replacements = {
        "ORIGIN": lib_base_dir,
        "LIB": system_lib_dir,
        "PLATFORM": system_processor_type,
    }
    for token, target in token_replacements.items():
        rpath = rpath.replace(f"${token}", target)  # $TOKEN
        rpath = rpath.replace(f"${{{token}}}", target)  # ${TOKEN}
    return rpath

