from __future__ import annotations

import functools
import itertools
import logging
from collections import defaultdict
from collections.abc import Iterable, Iterator, Mapping
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Optional, TypeVar

from auditwheel.elfutils import (
    elf_find_ucs2_symbols,
    elf_find_versioned_symbols,
    elf_is_python_extension,
    elf_references_PyFPE_jbuf,
)
from auditwheel.lddtree import DynamicExecutable, ldd
from auditwheel.policy import ExternalReference, Policy, WheelPolicies

from elftools.elf.elffile import ELFFile, ELFError

from . import json
from .genericpkgctx import InGenericPkgCtx

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class WheelAbIInfo:
    policies: WheelPolicies
    full_external_refs: dict[Path, dict[str, ExternalReference]]
    overall_policy: Policy
    external_refs: dict[str, ExternalReference]
    ref_policy: Policy
    versioned_symbols: dict[str, set[str]]
    sym_policy: Policy
    ucs_policy: Policy
    pyfpe_policy: Policy
    blacklist_policy: Policy
    machine_policy: Policy


@dataclass(frozen=True)
class WheelElfData:
    policies: WheelPolicies
    full_elftree: dict[Path, DynamicExecutable]
    full_external_refs: dict[Path, dict[str, ExternalReference]]
    versioned_symbols: dict[str, set[str]]
    uses_ucs2_symbols: bool
    uses_PyFPE_jbuf: bool


class RAbiError(Exception):
    """Root exception class"""


class NonBinaryPackage(RAbiError):
    """No ELF binaries in the package"""

    LOG_MESSAGE = (
        "This does not look like a binary package, no ELF executable "
        "or shared library file found in the package"
    )

    def __init__(self) -> None:
        msg = (
            "This does not look like a binary package, no ELF executable "
            "or shared library file found in the package"
        )
        super().__init__(msg)

    @property
    def message(self) -> str:
        return self.args[0]


def r_wheel_policies(*args, **kwargs):
    """Get wheel policies for R packages

    This is the same as WheelPolicies(), but with libR.so and libjvm.so excluded.
    See auditwheel.policy.WheelPolicies for argument options.
    """
    policies = WheelPolicies(*args, **kwargs)

    updated_policies = []
    for policy in policies._policies:
        new_whitelist = policy.whitelist.union({
            "libR.so",
            # Exclude Java, as bundling does not work for packages that link against it (e.g. rJava).
            "libjvm.so",
        })
        # Create new policies with updated whitelists since the original is frozen
        updated_policy = policy.__class__(**{**policy.__dict__, "whitelist": new_whitelist})
        updated_policies.append(updated_policy)
    policies._policies = updated_policies

    return policies


@functools.lru_cache
def get_r_elfdata(
    policies: WheelPolicies, pkg_fn: str, exclude: frozenset[str]
) -> WheelElfData:
    full_elftree: dict[Path, DynamicExecutable] = {}
    nonpy_elftree: dict[Path, DynamicExecutable] = {}
    full_external_refs: dict[Path, dict[str, ExternalReference]] = {}
    versioned_symbols: dict[str, set[str]] = defaultdict(set)
    uses_ucs2_symbols = False
    uses_PyFPE_jbuf = False

    with InGenericPkgCtx(pkg_fn) as ctx:
        is_binary_package = False

        for fn, elf in elf_file_filter(ctx.iter_files()):
            log.debug("found ELF file %s in package %s", fn, pkg_fn)
            is_binary_package = True

            log.debug("processing: %s", fn)
            elftree = ldd(fn, exclude=exclude)

            for key, value in elf_find_versioned_symbols(elf):
                log.debug("key %s, value %s", key, value)
                versioned_symbols[key].add(value)

            # There should not be any Python extensions in R packages, but this is kept as-is
            # so the remainder of the function makes more sense.
            is_py_ext, py_ver = elf_is_python_extension(fn, elf)

            # If the ELF is a Python extension, we definitely need to
            # include its external dependencies.
            if is_py_ext:
                full_elftree[fn] = elftree
                uses_PyFPE_jbuf |= elf_references_PyFPE_jbuf(elf)
                if py_ver == 2:
                    uses_ucs2_symbols |= any(
                        True for _ in elf_find_ucs2_symbols(elf)
                    )
                full_external_refs[fn] = policies.lddtree_external_references(
                    elftree, ctx.path
                )
            else:
                # If the ELF is not a Python extension, it might be
                # included in the package already because auditwheel repair
                # vendored it, so we will check whether we should include
                # its internal references later.
                nonpy_elftree[fn] = elftree

        if not is_binary_package:
            raise NonBinaryPackage

        # Get a list of all external libraries needed by ELFs in the package.
        needed_libs = {
            lib
            for elf in itertools.chain(full_elftree.values(), nonpy_elftree.values())
            for lib in elf.needed
        }

        # nonpy_elftree should contain all shared libraries in the package.
        for fn, elf_tree in nonpy_elftree.items():
            # If a non-pyextension ELF file is not needed by something else
            # inside the wheel, then it was not checked by the logic above and
            # we should walk its elftree.
            if fn.name not in needed_libs:
                full_elftree[fn] = elf_tree

            # Even if a non-pyextension ELF file is not needed, we
            # should include it as an external reference, because
            # it might require additional external libraries.
            full_external_refs[fn] = policies.lddtree_external_references(
                elf_tree, ctx.path
            )

    log.debug("full_elftree:\n%s", json.dumps(full_elftree))
    log.debug(
        "full_external_refs (will be repaired):\n%s", json.dumps(full_external_refs)
    )

    return WheelElfData(
        policies,
        full_elftree,
        full_external_refs,
        versioned_symbols,
        uses_ucs2_symbols,
        uses_PyFPE_jbuf,
    )


def elf_file_filter(paths: Iterable[Path]) -> Iterator[tuple[Path, ELFFile]]:
    """Filter through an iterator of filenames and load up only ELF
    files
    """

    for path in paths:
        if path.suffix == ".R":
            continue
        else:
            try:
                with open(path, "rb") as f:
                    candidate = ELFFile(f)
                    yield path, candidate
            except ELFError:
                # not an elf file
                continue


def get_external_libs(external_refs: dict[str, ExternalReference]) -> dict[Path, str]:
    """Get external library dependencies for all policies excluding the default
    linux policy
    :param external_refs: external references for all policies
    :return: {realpath: soname} e.g.
    {'/path/to/external_ref.so.1.2.3': 'external_ref.so.1'}
    """
    result: dict[Path, str] = {}
    for external_ref in external_refs.values():
        # linux tag (priority 0) has no white-list, do not analyze it
        if external_ref.policy.priority == 0:
            continue
        # go through all libs, retrieving their soname and realpath
        for libname, realpath in external_ref.libs.items():
            if realpath and realpath not in result:
                result[Path(realpath)] = libname
    return result


def get_versioned_symbols(libs: dict[Path, str]) -> dict[str, dict[str, set[str]]]:
    """Get versioned symbols used in libraries
    :param libs: {realpath: soname} dict to search for versioned symbols e.g.
    {'/path/to/external_ref.so.1.2.3': 'external_ref.so.1'}
    :return: {soname: {depname: set([symbol_version])}} e.g.
    {'external_ref.so.1': {'libc.so.6', set(['GLIBC_2.5','GLIBC_2.12'])}}
    """
    result = {}
    for path, elf in elf_file_filter(libs.keys()):
        # {depname: set(symbol_version)}, e.g.
        # {'libc.so.6', set(['GLIBC_2.5','GLIBC_2.12'])}
        elf_versioned_symbols: dict[str, set[str]] = defaultdict(set)
        for key, value in elf_find_versioned_symbols(elf):
            log.debug("path %s, key %s, value %s", path, key, value)
            elf_versioned_symbols[key].add(value)
        result[libs[path]] = elf_versioned_symbols
    return result


def get_symbol_policies(
    policies: WheelPolicies,
    versioned_symbols: dict[str, set[str]],
    external_versioned_symbols: dict[str, dict[str, set[str]]],
    external_refs: dict[str, ExternalReference],
) -> list[tuple[Policy, dict[str, set[str]]]]:
    """Get symbol policies
    Since white-list is different per policy, this function inspects
    versioned_symbol per policy when including external refs
    :param versioned_symbols: versioned symbols for the current wheel
    :param external_versioned_symbols: versioned symbols for external libs
    :param external_refs: external references for all policies
    :return: list of tuples of the form (policy, versioned_symbols),
    e.g. [(<Policy: manylinux...>, {'libc.so.6', set(['GLIBC_2.5'])})]
    """
    result = []
    for external_ref in external_refs.values():
        # skip the linux policy
        if external_ref.policy.priority == 0:
            continue
        policy_symbols = deepcopy(versioned_symbols)
        for soname in external_ref.libs:
            if soname not in external_versioned_symbols:
                continue
            ext_symbols = external_versioned_symbols[soname]
            for k in iter(ext_symbols):
                policy_symbols[k].update(ext_symbols[k])
        result.append(
            (policies.versioned_symbols_policy(policy_symbols), policy_symbols)
        )
    return result


def analyze_r_abi(
    policies: WheelPolicies,
    pkg_fn: str,
    exclude: frozenset[str],
    allow_graft: bool,
) -> WheelAbIInfo:
    data = get_r_elfdata(policies, pkg_fn, exclude)
    elftree_by_fn = data.full_elftree
    external_refs_by_fn = data.full_external_refs
    versioned_symbols = data.versioned_symbols

    external_refs: dict[str, ExternalReference] = {
        p.name: ExternalReference({}, {}, p) for p in policies
    }

    for fn in elftree_by_fn:
        update(external_refs, external_refs_by_fn[fn])

    log.debug("external reference info")
    log.debug(json.dumps(external_refs))

    external_libs = get_external_libs(external_refs)
    external_versioned_symbols = get_versioned_symbols(external_libs)
    symbol_policies = get_symbol_policies(
        policies, versioned_symbols, external_versioned_symbols, external_refs
    )
    symbol_policy = policies.versioned_symbols_policy(versioned_symbols)

    # let's keep the highest priority policy and
    # corresponding versioned_symbols
    symbol_policy, versioned_symbols = max(
        symbol_policies, key=lambda x: x[0], default=(symbol_policy, versioned_symbols)
    )

    ref_policy = max(
        (e.policy for e in external_refs.values() if len(e.libs) == 0),
        default=policies.linux,
    )

    blacklist_policy = max(
        (e.policy for e in external_refs.values() if len(e.blacklist) == 0),
        default=policies.linux,
    )

    ucs_policy = policies.linux if data.uses_ucs2_symbols else policies.highest
    pyfpe_policy = policies.linux if data.uses_PyFPE_jbuf else policies.highest

    overall_policy = min(
        symbol_policy,
        ucs_policy,
        pyfpe_policy,
        blacklist_policy,
    )
    if not allow_graft:
        overall_policy = min(overall_policy, ref_policy)

    return WheelAbIInfo(
        policies,
        external_refs_by_fn,
        overall_policy,
        external_refs,
        ref_policy,
        versioned_symbols,
        symbol_policy,
        ucs_policy,
        pyfpe_policy,
        blacklist_policy,
        # Ignoring machine_policy for now, as it is not needed for R
        None,
    )


_T = TypeVar("_T", ExternalReference, Optional[Path])


def update(d: dict[str, _T], u: Mapping[str, _T]) -> None:
    for k, v in u.items():
        if isinstance(v, ExternalReference):
            assert k in d
            assert isinstance(d[k], ExternalReference)
            assert d[k].policy == v.policy
            # update blacklist
            for lib, symbols in v.blacklist.items():
                if lib not in d[k].blacklist:
                    d[k].blacklist[lib] = sorted(symbols)
                else:
                    d[k].blacklist[lib] = sorted(
                        set(d[k].blacklist[lib]) | set(symbols)
                    )
            # libs
            update(d[k].libs, v.libs)
        elif isinstance(v, (Path, type(None))):
            d[k] = u[k]
        else:
            msg = f"can't update {d} with {k}:{v}"
            raise RuntimeError(msg)
