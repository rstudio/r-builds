from __future__ import annotations

import os

from .rtools import InRPackageTarballCtx, InRPackageDirCtx


def InGenericPkgCtx(
    in_path: str, out_path: str | None = None
) -> InRPackageTarballCtx | InRPackageDirCtx:
    """Factory that returns an InRPackageTarballCtx or InRPackageDirCtx context manager
    """
    if in_path.endswith(".tar.gz"):
        return InRPackageTarballCtx(in_path, out_path)
    elif os.path.isdir(in_path):
        return InRPackageDirCtx(in_path, out_path)

    raise ValueError(
        "Invalid package: %s. Package must be a .tar.gz file or directory." % in_path
    )
