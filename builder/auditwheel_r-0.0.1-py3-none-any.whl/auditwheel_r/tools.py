from __future__ import annotations

import os
import tarfile


def targz2dir(targz_fname: str, out_dir: str) -> None:
    """Extract `targz_fname` into output directory `out_dir`

    Parameters
    ----------
    targz_fname : str
        Filename of gzipped tarball (.tar.gz file) to write
    out_dir : str
        Directory path containing files to go in the gzipped tar archive
    """
    with tarfile.open(targz_fname, "r:gz") as t:
        t.extractall(path=out_dir)


def dir2targz(in_dir: str, targz_fname: str, change_dir: str | None = None) -> None:
    """Make a gzipped tar file `targz_fname` with contents of directory `in_dir`

    The recorded filenames are relative to the parent of `in_dir`, so doing a standard tar
    unpack of the resulting `targz_fname` in an empty directory will result in
    a single directory.

    Parameters
    ----------
    in_dir : str
        Directory path containing files to go in the gzipped tar archive
    targz_fname : str
        Filename of gzipped tar archive to write
    change_dir: str or None
        If not None, the directory to change to before adding files to the archive,
        equivalent to the tar -C flag.
    """
    arcname = None
    if change_dir is not None:
        arcname = os.path.relpath(in_dir, change_dir)

    # Format must NOT be POSIX/USTAR to avoid "using pax extended headers" warnings in R.
    # GNU format is broadly supported, and already the default for recent Python versions,
    # but this is set anyway to be very clear.
    with tarfile.open(targz_fname, "w:gz", format=tarfile.GNU_FORMAT) as t:
        t.add(in_dir, arcname=arcname)
