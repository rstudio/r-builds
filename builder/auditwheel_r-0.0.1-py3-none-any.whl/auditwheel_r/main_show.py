from __future__ import annotations

import logging

from auditwheel.architecture import Architecture
from auditwheel.libc import Libc

logger = logging.getLogger(__name__)


def configure_parser(sub_parsers):
    help = "Audit an R binary package for external shared library dependencies."
    p = sub_parsers.add_parser("show", help=help, description=help)
    p.add_argument("FILE", help="Path to R binary package file or directory.")
    p.set_defaults(func=execute)


def printp(text: str) -> None:
    from textwrap import wrap

    print()
    print("\n".join(wrap(text, break_long_words=False, break_on_hyphens=False)))


def execute(args, p):
    from os.path import basename, exists

    from . import json
    from .r_abi import NonBinaryPackage, analyze_r_abi, r_wheel_policies

    policies = r_wheel_policies(libc=Libc.detect(), arch=Architecture.detect())

    fn = basename(args.FILE)

    if not exists(args.FILE):
        p.error("cannot access %s. No such file or directory" % args.FILE)

    try:
        winfo = analyze_r_abi(policies, args.FILE, frozenset(), False)
    except NonBinaryPackage as e:
        logger.info(e.message)
        return 0

    libs_with_versions = [
        f"{k} with versions {v}" for k, v in winfo.versioned_symbols.items()
    ]

    printp(
        f'{fn} is consistent with the following platform tag: "{winfo.overall_policy.name}".'
    )

    if winfo.pyfpe_policy == policies.linux:
        printp(
            "This package uses the PyFPE_jbuf function, which is not compatible with the"
            " manylinux/musllinux tags. (see https://www.python.org/dev/peps/pep-0513/"
            "#fpectl-builds-vs-no-fpectl-builds)"
        )
        if args.verbose < 1:
            return 0

    if winfo.ucs_policy == policies.linux:
        printp(
            "This package is compiled against a narrow unicode (UCS2) "
            "version of Python, which is not compatible with the "
            "manylinux/musllinux tags."
        )
        if args.verbose < 1:
            return 0

    if winfo.machine_policy == policies.linux:
        printp("This package depends on unsupported ISA extensions.")
        if args.verbose < 1:
            return 0

    if len(libs_with_versions) == 0:
        printp(
            "The package references no external versioned symbols from "
            "system-provided shared libraries."
        )
    else:
        printp(
            "The package references external versioned symbols in these "
            f"system-provided shared libraries: {', '.join(libs_with_versions)}"
        )

    if winfo.sym_policy < policies.highest:
        printp(
            f'This constrains the platform tag to "{winfo.sym_policy.name}". '
            "In order to achieve a more compatible tag, you would "
            "need to recompile a new package from source on a system "
            "with earlier versions of these libraries, such as "
            "a recent manylinux image."
        )
        if args.verbose < 1:
            return 0


    libs = winfo.external_refs[policies.lowest.name].libs
    if len(libs) == 0:
        printp("The package requires no external shared libraries! :)")
    else:
        printp("The following external shared libraries are required by the package:")
        print(json.dumps(dict(sorted(libs.items()))))

    for p in policies:
        if p > winfo.overall_policy:
            libs = winfo.external_refs[p.name].libs
            if len(libs):
                printp(
                    f"In order to achieve the tag platform tag {p.name!r} "
                    "the following shared library dependencies "
                    "will need to be eliminated:"
                )
                printp(", ".join(sorted(libs.keys())))
            blacklist = winfo.external_refs[p.name].blacklist
            if len(blacklist):
                printp(
                    f"In order to achieve the tag platform tag {p.name!r} "
                    "the following black-listed symbol dependencies "
                    "will need to be eliminated:"
                )
                for key in sorted(blacklist.keys()):
                    printp(f"From {key}: " + ", ".join(sorted(blacklist[key])))
    return 0
