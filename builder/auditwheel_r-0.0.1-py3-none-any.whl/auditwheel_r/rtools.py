""" General tools for working with R packages

Tools that aren't specific to delocation
"""

from __future__ import annotations

import logging
import os
import re
import shutil
from os.path import abspath, basename
from os.path import join as pjoin
from pathlib import Path
from subprocess import check_output, CalledProcessError
from types import TracebackType
from typing import Generator

from auditwheel.tmpdirs import InTemporaryDirectory

from .tools import dir2targz, targz2dir

logger = logging.getLogger(__name__)


class RToolsError(Exception):
    pass


class InRPackageTarball(InTemporaryDirectory):
    """Context manager for doing things inside R packages

    On entering, you'll find yourself in the root tree of the package. If you've
    asked for an output package, then on exit we'll rewrite the package DESCRIPTION and
    pack stuff up for you.
    """

    def __init__(self, in_path: str, out_path: str | None = None) -> None:
        """Initialize in-package context manager

        Parameters
        ----------
        in_path : str
            filepath of package to unpack and work inside
        out_path : None or str:
            filepath of package to write after exiting. If None, don't write and
            discard
        """
        self.in_path = abspath(in_path)
        self.out_path = None if out_path is None else abspath(out_path)
        self.package_name = None
        # Relative path to package root, e.g. "curl" for a package named curl
        self.package_path = None
        # Relative path to package libs directory, e.g. "curl/libs" for a package named curl.
        # This is the directory where copied shared libraries should be stored.
        self.package_libs_path = None
        super().__init__()

    def __enter__(self) -> str:
        targz2dir(self.in_path, self.name)

        # Get the package name, which should always be the first subdirectory for tarballs
        _, dirnames, _ = next(os.walk(self.name))
        if len(dirnames) != 1:
            raise ValueError("package tarball should have exactly one sub-directory")
        self.package_name = dirnames[0]

        self.package_path = self.package_name
        self.package_libs_path = pjoin(self.package_path, "libs")

        return super().__enter__()

    def __exit__(
        self,
        exc: type[BaseException] | None,
        value: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if self.out_path is not None:
            pkg_dir = pjoin(self.name, self.package_name)
            dir2targz(pkg_dir, self.out_path, self.name)
        return super().__exit__(exc, value, tb)


class InRPackageTarballCtx(InRPackageTarball):
    """Context manager for doing things inside R packages

    On entering, you'll find yourself in the root tree of the package. If you've
    asked for an output package, then on exit we'll rewrite the package DESCRIPTION and
    pack stuff up for you.

    The context manager returns itself from the __enter__ method, so you can
    set things like ``out_path``. This is useful when processing in the package
    will dictate what the output package name is, or whether you want to save at
    all.

    The current path of the package contents is set in the attribute
    ``path``, e.g. ``/tmp/tmpkxk1u2ga``. The package name is set in the attribute ``package_name``.

    The relative path to the package root is set in the attribute ``package_path``,
    e.g. ``curl`` for a package named curl.

    The relative path to the package libs directory is set in the attribute ``package_libs_path``,
    e.g. ``curl/libs`` for a package named curl. This is the directory where copied shared
    libraries should be stored.
    """

    def __init__(self, in_path: str, out_path: str | None = None) -> None:
        """Init in-wheel context manager returning self from enter

        Parameters
        ----------
        in_path : str
            filepath of package to unpack and work inside
        out_path : None or str:
            filepath of package to write after exiting. If None, don't write and
            discard
        """
        super().__init__(in_path, out_path)
        self.path = None

    def __enter__(self):
        self.path = super().__enter__()
        return self

    def iter_files(self) -> Generator[Path]:
        if self.path is None:
            raise ValueError("This function should be called from context manager")

        # List package files relative to temp dir, e.g. "curl/libs/curl.so"
        for dirpath, dirnames, filenames in os.walk(self.path):
            for f in filenames:
                reldir = os.path.relpath(dirpath, self.path)
                yield Path(pjoin(reldir, f))


class InRPackageDir(InTemporaryDirectory):
    """Context manager for doing things inside R package directories

    Same as InRPackageTarball, but for directories instead of tarballs.
    """

    def __init__(self, in_path: str, out_path: str | None = None) -> None:
        """Initialize in-package context manager

        Parameters
        ----------
        in_path : str
            directory path of package to unpack and work inside
        out_path : None or str:
            directory path of package to write after exiting. If None, don't write and
            discard
        """
        self.in_path = abspath(in_path)
        self.out_path = None if out_path is None else abspath(out_path)
        self.package_name = None
        # Relative path to package root
        self.package_path = None
        # Relative path to package libs directory
        self.package_libs_path = None
        super().__init__()

    def __enter__(self) -> str:
        # Get the package name, which should be the directory name for package directories
        self.package_name = basename(self.in_path)

        shutil.copytree(self.in_path, self.name, dirs_exist_ok=True)

        # The package path for package directories is the current directory
        self.package_path = "."
        self.package_libs_path = pjoin(self.package_path, "libs")

        return super().__enter__()

    def __exit__(
        self,
        exc: type[BaseException] | None,
        value: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if self.out_path is not None:
            # TODO rewrite DESCRIPTION with platform tag
            # rewrite_description(self.name)
            shutil.copytree(self.name, self.out_path, dirs_exist_ok=True)
        return super().__exit__(exc, value, tb)


class InRPackageDirCtx(InRPackageDir):
    """Context manager for doing things inside R package directories

    Same as InRPackageTarballCtx, but for directories instead of tarballs.
    """

    def __init__(self, in_path: str, out_path: str | None = None) -> None:
        super().__init__(in_path, out_path)
        self.path = None

    def __enter__(self):
        self.path = super().__enter__()
        return self

    def iter_files(self) -> Generator[Path]:
        if self.path is None:
            raise ValueError("This function should be called from context manager")

        # List package files relative to temp dir, e.g. "libs/curl.so"
        for dirpath, dirnames, filenames in os.walk(self.path):
            for f in filenames:
                reldir = os.path.relpath(dirpath, self.path)
                yield Path(pjoin(reldir, f))


def add_platform(wheel_ctx: InRPackageTarballCtx | InRPackageDirCtx, platform: str) -> str:
    """Add platform tag `platform` to a package

    Add ``Platform`` field containing the platform tag to the package's
    ``DESCRIPTION`` file and ``Meta/package.rds`` file.

    Parameters
    ----------
    wheel_ctx : InWheelCtx
        An open wheel context
    platform : str
        platform tag to add to DESCRIPTION - e.g. ``'manylinux_2_31_x86_64'``
    """
    if wheel_ctx.path is None:
        raise ValueError(
            "This function should be called from wheel_ctx context manager"
        )

    r_platform = platform_tag_to_r_platform(platform)

    description_fname = pjoin(wheel_ctx.package_path, "DESCRIPTION")

    # Append Platform field to DESCRIPTION
    with open(description_fname, "a") as f:
        platform_field = f"Platform: {r_platform}\n"
        f.write(platform_field)
        logger.debug(f"rewrote DESCRIPTION file with {platform_field}")

    verify_r()
    # Read Meta/package.rds and add a new Platform field to the DESCRIPTION file, then saveRDS back to Meta/package.rds
    # Built$Platform is an R platform string like `R.version$platform`, e.g. "x86_64-pc-linux-gnu"
    try:
        script = f"""
pkg_rds_path <- file.path('{wheel_ctx.package_path}', 'Meta', 'package.rds')
p <- readRDS(pkg_rds_path)
p$DESCRIPTION['Platform'] <- '{r_platform}'
saveRDS(p, pkg_rds_path)
writeLines("Added field to Meta/package.rds, Platform: {r_platform}")
"""
        output = check_output(["R", "-s", "-e", script], text=True)
        logger.debug(f"Rewrote Meta/package.rds: {output}")
    except CalledProcessError as e:
        raise ValueError(f"Failed to rewrite Meta/package.rds: {e}")

    return wheel_ctx.out_path


def verify_r() -> None:
    """Checks if ``R`` is available on the PATH and runnable. Throws an exception if not."""
    if not shutil.which("R"):
        raise ValueError("Cannot find required utility `R` in PATH")
    try:
        output = check_output(["R", "--version"], text=True)
        logger.debug(f"Found R version: {output}")
    except CalledProcessError as e:
        raise ValueError(f"Could not call `R`: {e}")


# Regex pattern for platform tags, e.g. manylinux_2_31_x86_64 or musllinux_1_2_aarch64
PLATFORM_TAG_RE = re.compile(r"^(?P<linux_type>[^_]+)_(?P<version>[^_]+_[^_]+)_(?P<arch>.+)$")


def platform_tag_to_r_platform(platform: str) -> str:
    """Convert a platform tag to an R platform string

    Parameters
    ----------
    platform : str
        platform tag to convert to R platform string

    Returns
    -------
    str
        R platform string, e.g. x86_64-pc-linux-gnu-manylinux_2_31 or aarch64-pc-linux-musl-musllinux_1_2
    """
    m = PLATFORM_TAG_RE.match(platform)
    if m is None:
        raise ValueError(f"Invalid platform tag: {platform}")

    linux_type = m.group("linux_type")
    version = m.group("version")
    arch = m.group("arch")

    tag = f"{linux_type}_{version}"

    if linux_type == "manylinux":
        os_type = "pc-linux-gnu"
    elif linux_type == "musllinux":
        os_type = "pc-linux-musl"
    else:
        raise ValueError(f"Invalid linux type: {linux_type}")

    r_platform = f"{arch}-{os_type}-{tag}"
    return r_platform
