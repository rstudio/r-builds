from __future__ import annotations

import argparse
import logging
import shutil
from os.path import abspath, basename, exists

from auditwheel.architecture import Architecture
from auditwheel.libc import Libc
from auditwheel.patcher import Patchelf
from auditwheel.tools import EnvironmentDefault

from .r_abi import r_wheel_policies

logger = logging.getLogger(__name__)


def configure_parser(sub_parsers):
    policies = r_wheel_policies(libc=Libc.detect(), arch=Architecture.detect())
    policy_names = [p.name for p in policies if p != policies.linux]
    policy_names += [alias for p in policies for alias in p.aliases]
    policy_names += ["auto"]
    epilog = """PLATFORMS:
These are the possible target platform tags, as specified by PEP 600.
Note that old, pre-PEP 600 tags are still usable and are listed as aliases
below.
"""
    for p in policies:
        epilog += f"- {p.name}"
        if len(p.aliases) > 0:
            epilog += f" (aliased by {', '.join(p.aliases)})"
        epilog += "\n"
    help = """Vendor in external shared library dependencies of an R binary package.
If multiple packages are specified, an error processing one
package will abort processing of subsequent packages.
"""
    parser = sub_parsers.add_parser(
        "repair",
        help=help,
        description=help,
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("FILE", help="Path to R binary package file or directory.", nargs="+")
    parser.add_argument(
        "--plat",
        action=EnvironmentDefault,
        metavar="PLATFORM",
        env="AUDITWHEEL_PLAT",
        dest="PLAT",
        help="Desired target platform. See the available platforms under the "
        'PLATFORMS section below. (default: "auto")',
        choices=policy_names,
        default="auto",
    )
    parser.add_argument(
        "-L",
        "--lib-sdir",
        dest="LIB_SDIR",
        help=(
            "Subdirectory in packages to store copied libraries." ' (default: ".libs")'
        ),
        default=".libs",
    )
    parser.add_argument(
        "-w",
        "--wheel-dir",
        dest="WHEEL_DIR",
        type=abspath,
        help=("Directory to store delocated packages (default:" ' "wheelhouse/")'),
        default="wheelhouse/",
    )
    parser.add_argument(
        "--no-update-tags",
        dest="UPDATE_TAGS",
        action="store_false",
        help="Do not update the package DESCRIPTION file and Meta/package.rds with the platform tag",
        default=True,
    )
    parser.add_argument(
        "--no-strip",
        dest="STRIP",
        action="store_false",
        help="Do not strip external library symbols in the resulting package",
        default=True,
    )
    parser.add_argument(
        "--exclude",
        dest="EXCLUDE",
        help="Exclude SONAME from grafting into the resulting package "
        "(can be specified multiple times)",
        action="append",
        default=[],
    )
    parser.add_argument(
        "--only-plat",
        dest="ONLY_PLAT",
        action="store_true",
        help="Do not check for higher policy compatibility",
        default=False,
    )
    parser.set_defaults(func=execute)


def execute(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    import os

    from .repair_r import repair_r
    from .r_abi import NonBinaryPackage, analyze_r_abi

    exclude: frozenset[str] = frozenset(args.EXCLUDE)
    plat_base: str = args.PLAT

    policies = r_wheel_policies(libc=Libc.detect(), arch=Architecture.detect())

    for file in args.FILE:
        if not exists(file):
            parser.error(f"cannot access {file}. No such file")

        logger.info("Repairing %s", basename(file))

        if not exists(args.WHEEL_DIR):
            os.makedirs(args.WHEEL_DIR)

        try:
            wheel_abi = analyze_r_abi(policies, file, exclude, True)
        except NonBinaryPackage as e:
            logger.info(e.message)
            # Copy file as-is to the output directory
            shutil.copyfile(file, os.path.join(args.WHEEL_DIR, basename(file)))
            return 0

        if plat_base == "auto":
            if wheel_abi.overall_policy == policies.linux:
                # we're getting 'linux', override
                plat = policies.lowest.name
            else:
                plat = wheel_abi.overall_policy.name
        else:
            plat = f"{plat_base}_{policies.architecture.value}"
        requested_policy = policies.get_policy_by_name(plat)

        if requested_policy > wheel_abi.sym_policy:
            msg = (
                f'cannot repair "{file}" to "{plat}" ABI because of the '
                "presence of too-recent versioned symbols. You'll need to compile "
                "the package on an older toolchain."
            )
            parser.error(msg)

        if requested_policy > wheel_abi.ucs_policy:
            msg = (
                f'cannot repair "{file}" to "{plat}" ABI because it was '
                "compiled against a UCS2 build of Python. You'll need to compile "
                "the package against a wide-unicode build of Python."
            )
            parser.error(msg)

        if requested_policy > wheel_abi.blacklist_policy:
            msg = (
                f'cannot repair "{file}" to "{plat}" ABI because it '
                "depends on black-listed symbols."
            )
            parser.error(msg)

        abis = [requested_policy.name, *requested_policy.aliases]
        if (not args.ONLY_PLAT) and requested_policy < wheel_abi.overall_policy:
            logger.info(
                (
                    "Package is eligible for a higher priority tag. "
                    "You requested %s but I have found this package is "
                    "eligible for %s."
                ),
                plat,
                wheel_abi.overall_policy.name,
            )
            abis = [
                wheel_abi.overall_policy.name,
                *wheel_abi.overall_policy.aliases,
                *abis,
            ]

        patcher = Patchelf()
        out_wheel = repair_r(
            wheel_abi,
            file,
            abis=abis,
            lib_sdir=args.LIB_SDIR,
            out_dir=args.WHEEL_DIR,
            update_tags=args.UPDATE_TAGS,
            patcher=patcher,
            exclude=exclude,
            strip=args.STRIP,
        )

        if out_wheel is not None:
            logger.info("\nFixed-up package written to %s", out_wheel)
    return 0
